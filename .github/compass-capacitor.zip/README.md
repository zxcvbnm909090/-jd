# بوصلة + إعلانات AdMob (Capacitor)

## المتطلبات
- Node.js
- Android Studio

## الخطوات
1. افتح الطرفية داخل هذا المجلد ونفّذ:

   npm install @capacitor/core @capacitor/android @capacitor-community/admob
   npm install -D @capacitor/cli

2. غيّر `appId` في `capacitor.config.json` إلى معرّف فريد لك مثل `com.ahmed.compass`.

3. أضف منصة أندرويد:

   npx cap add android
   npx cap sync android

4. افتح الملف:
   android/app/src/main/AndroidManifest.xml
   وأضف السطرين التاليين داخل وسم <application> قبل إغلاقه:

   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="ca-app-pub-3940256099942544~3347511713"/>

   (هذا معرّف التطبيق التجريبي من Google. استبدله بمعرّف تطبيقك من AdMob قبل النشر.)

5. شغّل المشروع:

   npx cap open android

   ثم من Android Studio اضغط Run على هاتف حقيقي (الحساس لا يعمل في المحاكي).
   سيظهر إعلان تجريبي أسفل الشاشة.

## قبل النشر
1. أنشئ حساباً في admob.google.com وأضف تطبيقك واحصل على:
   - App ID (يوضع في AndroidManifest.xml)
   - Banner Ad Unit ID (يوضع في `BANNER_ID` داخل www/index.html)
2. اجعل `TESTING=false` في www/index.html.
3. لا تضغط على إعلاناتك الحقيقية بنفسك، فقد يُغلق حسابك.
4. للحصول على ملف APK موقّع: في Android Studio اختر
   Build > Generate Signed Bundle / APK > APK.
   احتفظ بملف المفاتيح (keystore) وكلمة سره في مكان آمن.
5. ارفع الـ APK على Samsung Galaxy Store من seller.samsungapps.com.

## بعد تعديل www/index.html
   npx cap sync android
